LetsMeetVerse — desktop version (Linux, v0.1.0)
========================================

Unzip, then run ./LetsMeetVerse-linux_x64 (chmod +x it first if needed). Needs WebKitGTK 4.1
(Debian/Ubuntu: sudo apt install libwebkit2gtk-4.1-0).

The game runs entirely on this computer (offline, single-player town). Your progress is saved automatically
in the app's own browser storage and stays when you replace this folder with a newer version.
Port 45127 on localhost is used while the game is open.

Play in the browser or with friends online: https://letsmeetverse.com
游戏完全在本机运行，进度自动保存。网页版：https://letsmeetverse.com

Licences: see the LICENSES folder (Neutralinojs: MIT; Nunito, Fredoka, Bree Serif and Source Sans 3 fonts: SIL Open Font License 1.1).
