LetsMeetVerse — desktop version (Windows, v0.1.0)
========================================

Unzip the whole folder anywhere (Desktop, Documents, a USB stick), then double-click LetsMeetVerse.exe.
Windows may ask "Windows protected your PC" the first time because the app is new and not code-signed:
click "More info" then "Run anyway".

Needs the Microsoft Edge WebView2 Runtime. It is part of Windows 11 and of up-to-date Windows 10. If the window
stays blank, install it from https://developer.microsoft.com/microsoft-edge/webview2/ (Evergreen Runtime).

The game runs entirely on this computer (offline, single-player town). Your progress is saved automatically
in the app's own browser storage and stays when you replace this folder with a newer version.
Port 45127 on localhost is used while the game is open.

Play in the browser or with friends online: https://letsmeetverse.com
游戏完全在本机运行，进度自动保存。网页版：https://letsmeetverse.com

Licences: see the LICENSES folder (Neutralinojs: MIT; Nunito, Fredoka, Bree Serif and Source Sans 3 fonts: SIL Open Font License 1.1).
